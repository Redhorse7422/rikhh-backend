export interface BaseDto {
  id: string;
  createdAt: Date;
  updatedAt: Date;
} 