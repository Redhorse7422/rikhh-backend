import { createId } from "@paralleldrive/cuid2";

export const cuid = () => createId();
