export enum USER_TYPE {
  ADMIN = "admin",
  SELLER = "seller",
  BUYER = "buyer",
}
