// src/modules/checkout/entities/order.enums.ts

export enum ORDER_STATUS {
  PENDING = "pending",
  SELLER_NOTIFIED = "seller_notified", // New: Seller has been notified
  SELLER_ACCEPTED = "seller_accepted", // New: Seller accepted the order
  CONFIRMED = "confirmed",
  PROCESSING = "processing",
  SHIPPED = "shipped",
  DELIVERED = "delivered",
  CANCELLED = "cancelled",
  REFUNDED = "refunded",
  RETURNED = "returned",
}

export enum PAYMENT_STATUS {
  PENDING = "pending",
  AUTHORIZED = "authorized",
  CAPTURED = "captured",
  FAILED = "failed",
  CANCELLED = "cancelled",
  REFUNDED = "refunded",
  PARTIALLY_REFUNDED = "partially_refunded",
}

export enum PAYMENT_METHOD {
  CASH_ON_DELIVERY = "cash_on_delivery",
}

export enum COMMISSION_STATUS { // New Enum
  PENDING = "pending",
  CALCULATED = "calculated",
  PAID = "paid",
  CANCELLED = "cancelled",
}
