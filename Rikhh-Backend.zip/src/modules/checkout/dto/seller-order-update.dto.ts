import { IsUUID, IsEnum, IsOptional, IsString, IsDateString } from "class-validator";
import { ORDER_STATUS } from "../entities/order.enums";

export class SellerOrderUpdateDto {
  @IsUUID()
  orderId: string;

  @IsEnum(ORDER_STATUS)
  status: ORDER_STATUS;

  @IsOptional()
  @IsString()
  notes?: string;

  @IsOptional()
  @IsString()
  trackingNumber?: string;

  @IsOptional()
  @IsDateString()
  estimatedDeliveryDate?: string;
}
