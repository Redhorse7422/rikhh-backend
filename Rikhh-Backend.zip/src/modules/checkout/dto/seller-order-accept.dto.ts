import { IsUUID, IsOptional, IsString, IsNumber, Min, Max } from "class-validator";

export class SellerOrderAcceptDto {
  @IsUUID()
  orderId: string;

  @IsOptional()
  @IsString()
  notes?: string;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(30)
  estimatedProcessingTime?: number; // in days
}
