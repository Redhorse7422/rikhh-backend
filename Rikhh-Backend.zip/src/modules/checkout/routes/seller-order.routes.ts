import { Router } from "express";
import { DataSource } from "typeorm";
import { SellerOrderController } from "../controllers/seller-order.controller";
import { authenticate } from "../../auth/middlewares/auth.middleware";
import { requireSeller } from "../../auth/middlewares/user-type.middleware";

export function createSellerOrderRoutes(dataSource: DataSource): Router {
  const router = Router();
  const sellerOrderController = new SellerOrderController(dataSource);

  // Apply authentication and authorization to all routes
  router.use(authenticate);
  router.use(requireSeller);

  // Get seller's orders
  router.get("/orders", sellerOrderController.getSellerOrders.bind(sellerOrderController));

  // Accept an order
  router.post("/orders/accept", sellerOrderController.acceptOrder.bind(sellerOrderController));

  // Update order status
  router.put("/orders/status", sellerOrderController.updateOrderStatus.bind(sellerOrderController));

  // Get notifications
  router.get("/notifications", sellerOrderController.getNotifications.bind(sellerOrderController));

  // Mark notification as read
  router.put("/notifications/:notificationId/read", sellerOrderController.markNotificationAsRead.bind(sellerOrderController));

  // Get commission summary
  router.get("/commissions/summary", sellerOrderController.getCommissionSummary.bind(sellerOrderController));

  return router;
}
